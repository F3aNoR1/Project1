---
name: General issue
about: File a bug report, a suggestion or a proposal related to the website or documentation
title: ''
labels: ''
assignees: ''
---

<!-- Please enter a short, clear description of the bug, the suggestion or proposal related to the website or documentation. -->
<!-- This repository is only for the website https://files-community.github.io/ and the documentation. For bugs and proposals related to the Files app its self, please file an issue on the Files GitHub repository: https://github.com/files-community/Files -->
# <Your issue Title>