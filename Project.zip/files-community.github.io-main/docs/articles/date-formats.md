# Date Formats

Files comes with two different options to let you customize the date format.

**Application**

The default date format uses the following format _Wednesday, June 3, 2020_.

**System**

System is a little more compact and uses this format _6/3/2020_.
