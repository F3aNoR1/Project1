- [Overview](/)
- Configuring Files
  - [Terminal Profiles](/articles/terminal-profiles.md)
  - [Performance Settings](/articles/performance-settings.md)
  - [Date Formats](/articles/date-formats.md)
  - [Custom Themes](/articles/custom-themes.md)
  - [Keyboard Shortcuts](/articles/keyboard-shortcuts.md)
  - [Configuring the Win + E Shortcut](/articles/configure-win-e.md)
  - [Replacing File Explorer with Files](/articles/replace-file-explorer.md)

- Contributing

  - [Building Files from source](/articles/building-source.md)
  - [Translating Files](/articles/translating-files.md)
  - [Building Extensions for Files](/articles/building-extensions.md)
  - [Code Style](/articles/code-style.md)

- [Languages](/articles/languages.md)
