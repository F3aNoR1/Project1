# What is Files?
Files is a file manager which leverages the latest features of the Windows platform including Fluent Design, seamless updates, and APIs which enable the performance and lifecycle behavior that users expect. Whether you want to simplify your experience with your files or try something new, Files is a one-stop solution for exploring your files on the fly.

# Vision for Files
The vision for Files is to make it the best file manager while keeping it simple and easy to use. Whether it's implementing new features, or pushing the boundaries of the platform, your input will help shape the future of Files.

# Download Files 
- [Microsoft Store](https://www.microsoft.com/store/apps/9NGHP3DX8HDX)
- [GitHub](https://github.com/files-community/Files/releases)
