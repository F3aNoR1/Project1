- [主頁](/)
- 自訂您的 Files
  - [終端機配置編輯範例](/articles/terminal-profiles.md)
  - [性能最佳化](/articles/performance-settings.md)
  - [日期格式](/articles/date-formats.md)
  - [客製化主題](/articles/custom-themes.md)
  - [鍵盤快捷鍵](/articles/keyboard-shortcuts.md)
  - [Win + E 快捷鍵配置](/articles/configure-win-e.md)
  - [開啟項目時預設啟動 Files](/articles/replace-file-explorer.md)

- 貢獻

  - [翻譯 Files](/articles/translating-files.md)
  - [為 Files 開發擴充功能](/articles/building-extensions.md)
  - [程式風格準則](/articles/code-style.md)

- [語言](/articles/languages.md)
